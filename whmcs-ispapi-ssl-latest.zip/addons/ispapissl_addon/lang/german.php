<?php

// ISPAPI SSL Addon Language File - German

$_ADDONLANG = [
    'productGroupDescription' => "Produktgruppe auswählen, der die neuen Produkte zugewiesen werden sollen",
    'roundAllCurrencies' => "Alle Währungen runden",
    'roundAllCurrenciesDescription' => "Umgerechnete Preise ebenfalls runden",
    'products' => "Produkte",
    'certificate' => "SSL-Zertifikat",
    'autoRegistration' => "Auto-Registrierung aktiviert"
];
