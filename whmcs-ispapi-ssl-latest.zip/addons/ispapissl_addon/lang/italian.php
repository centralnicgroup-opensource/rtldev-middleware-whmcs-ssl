<?php

// ISPAPI SSL Addon Language File - Italian

$_ADDONLANG = [
    'productGroupDescription' => "Scegli il gruppo al quale assegnare i nuovi prodotti",
    'roundAllCurrencies' => "Arrotonda tutte le valute",
    'roundAllCurrenciesDescription' => "Arrotonda i prezzi convertiti",
    'products' => "prodotti",
    'certificate' => "Certificato SSL",
    'autoRegistration' => "Registrazione automatica attivata"
];
