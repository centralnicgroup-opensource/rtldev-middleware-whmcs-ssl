<?php

// ISPAPI SSL Addon Language File - English

$_ADDONLANG = [
    'productGroupDescription' => "Choose product group new products should be assigned to",
    'roundAllCurrencies' => "Apply rounding to all currencies",
    'roundAllCurrenciesDescription' => "Also round the converted prices",
    'products' => "products",
    'certificate' => "SSL Certificate",
    'autoRegistration' => "Auto-registration enabled"
];
