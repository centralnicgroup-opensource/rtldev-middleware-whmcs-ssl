# [7.1.0](https://github.com/hexonet/whmcs-ispapi-ssl/compare/v7.0.0...v7.1.0) (2018-10-22)


### Bug Fixes

* **Makefile:** setup working process ([7f7ec8a](https://github.com/hexonet/whmcs-ispapi-ssl/commit/7f7ec8a))
* **package.json:** semantic-release setup ([9e0de8b](https://github.com/hexonet/whmcs-ispapi-ssl/commit/9e0de8b))
* **test:** tmp. deactivate tests ([6f71b5d](https://github.com/hexonet/whmcs-ispapi-ssl/commit/6f71b5d))


### Features

* **github:** github migration ([00ba637](https://github.com/hexonet/whmcs-ispapi-ssl/commit/00ba637))
* **travis:** add initial configuration ([e21c04d](https://github.com/hexonet/whmcs-ispapi-ssl/commit/e21c04d))
