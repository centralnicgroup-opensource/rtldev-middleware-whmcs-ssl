<?php

// ISPAPI SSL Language File - English

$_LANG = [
    'adminContact' => 'Admin Contact',
    'billingContact' => 'Billing Contact',
    'created' => 'Created',
    'expiration' => 'Expiration',
    'orderId' => 'Order ID',
    'owner' => 'Owner',
    'sslcacrt' => 'CA / Intermediate Certificate',
    'sslcrt' => 'Certificate',
    'sslprocessingstatus' => 'Processing Status',
    'sslresendcertapproveremail' => 'Resend Approver Email',
    'sslresendsuccess' => 'Successfully resent the approver email',
    'techContact' => 'Tech Contact',
    'updated' => 'Updated',
    'vendorId' => 'Vendor Order ID',
    'webServerType' => 'Web Server Type'
];
